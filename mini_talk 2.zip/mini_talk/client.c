/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ryagoub <ryagoub@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/09 12:19:30 by ryagoub           #+#    #+#             */
/*   Updated: 2024/02/12 15:19:05 by ryagoub          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "serverclient.h"

void	convert_to_bits(int pid, char *str)
{
	int	i;
	int	b;
	int	bit;

	i = 0;
	b = 7;
	while (str[i] != '\0')
	{
		b = 7;
		while (b >= 0)
		{
			bit = (str[i] >> b & 1);
			if (bit == 1)
				kill(pid, SIGUSR1);
			else
				kill(pid, SIGUSR2);
			b--;
			usleep(200);
		}
		i++;
	}
}

int	check_for_errors(char *arg)
{
	int	i;

	i = 0;
	while (arg[i] != '\0')
	{
		if (arg[i] >= '0' && arg[i] <= '9')
			i++;
		else
			return (0);
	}
	return (1);
}

int	main(int ac, char **av)
{
	if (ac == 3)
	{
		if (check_for_errors(av[1]) && av[2])
			convert_to_bits(ft_atoi(av[1]), av[2]);
	}
}
