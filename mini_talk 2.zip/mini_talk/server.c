/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ryagoub <ryagoub@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/08 11:16:02 by ryagoub           #+#    #+#             */
/*   Updated: 2024/02/12 16:25:45 by ryagoub          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "serverclient.h"
#include <stdio.h>
#include <stdlib.h>

void	handle_signal(int sig)
{
	static int	c;
	static int	bits;
	int			res;
	int			counter;

	res = 1;
	if (!bits && !c)
		bits = 7;
	counter = bits;
	if (sig == SIGUSR1)
	{
		while (counter)
		{
			counter--;
			res = 2 * res;
		}
		c = c + res;
		printf("%d\n",c);
	}
	bits--;
	if (bits == 0)
	{
		ft_putchar(c);
		c = 0;
	}
}

int	main(void)
{
	ft_putnbr(getpid());
	while (1)
	{
		signal(SIGUSR1, handle_signal);
		signal(SIGUSR2, handle_signal);
	}
	sleep(1);
}
